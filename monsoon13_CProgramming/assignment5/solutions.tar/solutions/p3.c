#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define M 1000000007
struct node
{
	int rank,key;
	struct node *next;
	struct node *prev;
};
typedef struct node node;
typedef struct node cll;
cll *a,*b;					// the two rings
int n;						// the number of nodes present in the rings at a given instant
void delete_head()
{
	cll *next,*prev;
	next = a->next;
	prev = a->prev;
	prev->next=next;
	next->prev=prev;
	next=a;
	a=a->next;
	free(next);
	next = b->next;
	prev = b->prev;
	prev->next=next;
	next->prev=prev;
	b=b->next;
	n--;
	return;
}
void delete_tail()
{
	cll *next,*prev,*tail;

	tail=a->prev;
	next=a;
	prev=tail->prev;
	prev->next=next;
	next->prev=prev;
	
	tail=b->prev;
	next=b;
	prev=tail->prev;
	prev->next=next;
	next->prev=prev;
	n--;
	return;
}
void insert(int key , cll **l)
{
	if(*l==NULL)
	{
		*l=(cll*)malloc(sizeof(cll));
		(*l)->key=key;
		(*l)->next=(*l)->prev=*l;
		return;
	}
	else if((*l)->next==*l){	// just one node is present
		cll *n=(cll*)malloc(sizeof(cll));
		n->key=key;
		n->next=n->prev=*l;
		(*l)->next=(*l)->prev=n;
		return;
	}
	cll *n=(cll*)malloc(sizeof(cll));
	n->key=key;
	n->next=*l;
	n->prev=(*l)->prev;
	(*l)->prev->next=n;
	(*l)->prev=n;
	return;
}
void printKeysRanks(cll *l, int total)
{
	while(total--){
		printf("(%d,%d)  ",l->key,l->rank);
		l=l->next;
	}
	printf("\n");
	return;
}
void rotate_a(unsigned long long r)
{
	unsigned long long nn = n; 
	r=r%nn;
	if(r==0)
		return;
	while(r--)
		a=a->next;
	return;
}
void rotate_b(unsigned long long l)
{
	unsigned long long nn = n; 
	l=l%nn;
	if(l==0)
		return;
	while(l--)
		b=b->prev;
	return;
}
int power_modulo(int a, int b)
{
	long long int x=1,y=a;
	while(b>0){
		if(b%2==1){
			x=(x*y)%M;
		}
		y=(y*y)%M;
		b=b/2;
	}
	return x%M;
}
int get_beauty()
{
	int i;
	cll *ta=a,*tb=b;
	int ans=0;
	for(i=0;i<n;i++){
		ans = (ans + (power_modulo(ta->key,tb->rank) + power_modulo(tb->key,ta->rank))%M)%M;
		ta=ta->next;
		tb=tb->next;
	}
	return ans;
}
int main()
{
	int m;
	int i;
	cll *t;
	int op;
	unsigned long long r,l;
	char position[10];
	a=b=NULL;
	scanf("%d%d",&n,&m);
	int rank,key;
	for(i=0;i<n;i++){
		scanf("%d",&key);
		insert(key,&a);
	}
	for(i=0;i<n;i++){
		scanf("%d",&key);
		insert(key,&b);
	}
	t=a;
	for(i=0;i<n;i++){
		scanf("%d",&rank);
		t->rank=rank;
		t=t->next;
	}
	t=b;
	for(i=0;i<n;i++){
		scanf("%d",&rank);
		t->rank=rank;
		t=t->next;
	}
	//printKeysRanks(a,n);
	//printKeysRanks(b,n);
	for(i=0;i<m;i++){
		scanf("%d",&op);
		if(op==1){
			scanf("%s",position);
			if(strcmp(position,"head")==0)
				delete_head();
			else
				delete_tail();
			printf("done\n");
		}
		else{
			scanf("%llu%llu",&r,&l);
			if(r>0)
				rotate_a(r);
			if(l>0)
				rotate_b(l);
			printf("%d\n",get_beauty());
		}
	}
	return 0;
}
