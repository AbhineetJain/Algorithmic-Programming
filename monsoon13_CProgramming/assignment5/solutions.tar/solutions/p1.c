#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX_SUB 10
struct record
{
	int roll;
	int marks[MAX_SUB];
	int prev[MAX_SUB];
	int next[MAX_SUB];
	char name[11];
};
typedef struct record record;
struct map
{
	char name[11];
	int roll;
};
typedef struct map map;
int pk;
int cmp1( const void *l , const void *r)
{
	return ((record*)l)->marks[pk] < ((record*)r)->marks[pk];
}
int cmp2( const void *l , const void *r)
{
	return ((record*)l)->roll > ((record*)r)->roll ;
}
int cmp3(const void *l, const void *r)
{
	int v = strcmp(((map*)l)->name,((map*)r)->name);
	if(v>0)
		return 1;
	return 0;
}
map *m;						// name --> roll number mapping
record *r;
int n,k;
int getroll(char *name)
{
	int low,high,mid;
	low=1;
	high=n;
	int v;
	while(low<=high){
		mid=(low+high)/2;
		v=strcmp(m[mid].name,name);
		if(v==0)
			return m[mid].roll;
		else if(v<0)
			low=mid+1;
		else
			high=mid-1;
	}
	return -1;
}
void delete(int roll)
{
	int prev,next;
	for(pk=0;pk<k;pk++){
		prev = r[roll].prev[pk];
		next = r[roll].next[pk];
		if(next && prev){	// neither first nor last
			r[prev].next[pk]=next;
			r[next].prev[pk]=prev;
		}
		else if(!next){		// last element
			r[prev].next[pk]=0;
		}
		else{			// first
			r[next].prev[pk]=0;
		}
	}
	return;
}
int main()
{
	int q;
	int i,j;
	int roll=1;
	int ps;
	char option[10];
	int pq;
	char name[100];
	scanf("%d%d%d",&n,&k,&q);
	r = (record*)malloc((n+1)*(sizeof(record)));
	m = (map*)malloc((n+1)*(sizeof(map)));
	for(i=1;i<=n;i++){
		scanf("%s",m[i].name);
		for(j=0;j<k;j++)
			scanf("%d",&r[i].marks[j]);
		m[i].roll=r[i].roll=roll;
		strcpy(r[i].name,m[i].name);
		roll++;
	}
	for(pk=0;pk<k;pk++){
		qsort(r+1,n,sizeof(record),cmp1);
		r[1].prev[pk]=0;
		r[1].next[pk]=r[2].roll;
		r[n].next[pk]=0;
		r[n].prev[pk]=r[n-1].roll;
		for(i=2;i<n;i++){
			r[i].next[pk]=r[i+1].roll;
			r[i].prev[pk]=r[i-1].roll;
		}
	}
	qsort(r+1,n,sizeof(record),cmp2);
	qsort(m+1,n,sizeof(map),cmp3);
	for(i=0;i<q;i++){
		scanf("%d%s",&pq,name);
		roll=getroll(name);
		if(pq<3){
			if(pq==1){
				printf("%s ",name);
				for(j=0;j<k-1;j++)
					printf("%d ",r[roll].marks[j]);
				printf("%d\n",r[roll].marks[j]);
			}
			else{
				delete(roll);
				printf("done\n");
			}
		}
		else{
			scanf("%d %s",&ps,option);
			ps--;
			if(strcmp(option,"next")==0){
				if(r[roll].next[ps]==0)
					printf("last\n");
				else{
					roll=r[roll].next[ps];
					printf("%s ",r[roll].name);
					for(j=0;j<k-1;j++)
						printf("%d ",r[roll].marks[j]);
					printf("%d\n",r[roll].marks[j]);	
					
				}					
			}
			else{
				roll=r[roll].prev[ps];
				if(roll==0)
					printf("first\n");
				else{
					printf("%s ",r[roll].name);
					for(j=0;j<k-1;j++)
						printf("%d ",r[roll].marks[j]);
					printf("%d\n",r[roll].marks[j]);	
				}
			}
		}
	}
	return 0;
}
