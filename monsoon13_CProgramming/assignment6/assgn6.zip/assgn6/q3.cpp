#include<stdio.h>
#include<stdlib.h>

typedef struct name{
    int value;
    struct name *next;
}node;


node* makelist(node *start,int n)
{
    node *temp;
    int i=1;
    start=(node *)malloc(sizeof(node));
    temp=start;
    start->value=i;
    while(i<n)
    {
	temp->next=(node *)malloc(sizeof(node));
	temp=temp->next;
	i++;
	temp->value=i;
    }
    temp->next=start;
    return start;
}

int main()
{
    int i,m,n,j,k,*a;
    scanf("%d",&m);
    for(i=0;i<m;i++)
    {
	scanf("%d",&n);
	a=(int *)malloc(sizeof(int)*(n+1));
	node *start;
	start=makelist(start,n);
	j=1;
	while(start->next!=start)
	{
	    for(k=1;k<j;k++)
		start=start->next;
	    if(start->next!=NULL)
	    {
		a[start->next->value]=j;
		start->next=start->next->next;
	    }
	    start=start->next;
	    j++;
	}
	a[start->value]=j;
	for(j=1;j<n;j++)
	    printf("%d ",a[j]);
	printf("%d\n",a[j]);
	free(a);
    }	
    return 0;
}

