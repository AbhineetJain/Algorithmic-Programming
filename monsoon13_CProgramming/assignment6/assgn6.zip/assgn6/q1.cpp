#include<cstdio>
#include<cstring>
#include<cstdlib>
unsigned int mask[1010][32]={{0}};
long long int ans[1011][1011]={{0}};
int main()
{
	int n,m,q,i,j,k,x,y;
	long long result=0,count;
	scanf("%d%d%d",&n,&m,&q);
	for (i=0;i<m;i++)
	{
		scanf("%d%d",&x,&y);
		j=y/32;
		y=y%32;
		mask[x][j+1]=mask[x][j+1]|(1<<y);
	}
	memset(ans,0,sizeof(ans));
	for (i=1;i<=n;i++)
	{
		for (j=i+1;j<=n;j++)
		{
			count=0;
			for (k=1;k<=32;k++)
			{
				count+=__builtin_popcount(mask[i][k]&mask[j][k]);
			}
			if (count>=2)
				result+=((long long)count*(count-1))/2;
			ans[i][j]=count;
			ans[j][i]=count;
		}
	}
	printf("%lld\n",result);
	while (q--){
		scanf("%d%d",&x,&y);
		j=y/32;
		y=y%32;
		unsigned int a=0;
		a=mask[x][j+1] & (1<<y);
		mask[x][j+1]=mask[x][j+1] & (~(1<<y));
		for (i=1;i<=n;i++){
			if (i==x) continue;
			else{
				unsigned int b=0;
				b=mask[i][j+1] & (1<<y);
				if (a!=0 and b!=0){
					if (ans[x][i]>=2) result = result - (ans[x][i]-1);
					ans[x][i]--;
					ans[i][x]--;
				}
			}
		}
		printf("%lld\n",result);
	}
}
