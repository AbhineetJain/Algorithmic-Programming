//Author:Aman Agarwal

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct ptr
{
	char *txt;
	struct ptr *next;
}stud;
stud *arr[30]={NULL};
void sorted_insert(int x,char s[20])
{
	stud *tmp=arr[x],*tmp2;
	if(tmp->next==NULL)
	{
		tmp->next=(stud*)malloc(sizeof(stud));
		tmp->next->next=NULL;
		tmp->next->txt=(char*)malloc(sizeof(char)*20);
		strcpy((tmp->next)->txt,s);
	}
	else
	{
		while(strcmp(s,tmp->next->txt)>0)
		{
			tmp=tmp->next;
			if(tmp->next==NULL)
			{
				//tmp=tmp->next;
				tmp->next=(stud*)malloc(sizeof(stud));
				tmp->next->next=NULL;
				tmp->next->txt=(char*)malloc(sizeof(char)*20);
				strcpy(tmp->next->txt,s);
				return;
			}
		}
		tmp2=(stud*)malloc(sizeof(stud));
		tmp2->txt=(char*)malloc(sizeof(char)*20);
		strcpy(tmp2->txt,s);
		tmp2->next=tmp->next;
		tmp->next=tmp2;
	}
}
void del(int x,char s[20])
{
	stud *tmp=arr[x];
	if(tmp->next==NULL)
		return;
	else
	{
		while(tmp->next!=NULL)
		{
		if((strcmp(tmp->next->txt,s))==0)
		{
			stud *d=tmp->next;
			tmp->next=tmp->next->next;
			free(d);
			return;
		}
		tmp=tmp->next;
		}
	}
}
int main()
{
	int n,i;
	scanf("%d",&n);
	char tmpp,s[20];
	//scanf("%c",&tmp);
	for(i=0;i<27;i++)
	{
		arr[i]=malloc(sizeof(stud));
		arr[i]->next=NULL;
	}
	while(n--)
	{
		scanf("%s",s);
		//scanf("%c",&tmp);
		int x=(s[0]-'a');
		sorted_insert(x,s);
	}
	int q,ch;
	scanf("%d",&q);
	while(q--)
	{
		scanf("%d",&ch);
		scanf("%c",&tmpp);
		scanf("%s",s);
		int x=(s[0]-'a');
		if(ch==1)
			sorted_insert(x,s);
		else if(ch==2)
			del(x,s);
		else
		{
			stud* tmp=arr[x]->next;
			while(tmp)
			{
				printf("%s\n",tmp->txt);
				tmp=tmp->next;
			}
		}
	}
	/*for(i=0;i<27;i++)
	{
		if(arr[i]->next!=NULL)
		{
			stud* tmp=arr[i]->next;
			while(tmp)
			{
				printf("%s\n",tmp->txt);
				tmp=tmp->next;
			}
		}
	}*/
}
